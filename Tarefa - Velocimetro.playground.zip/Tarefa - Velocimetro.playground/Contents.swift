//: Playground - noun: a place where people can play

import UIKit

enum Velocidades:Int {
	case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
	
	init(velocidadInicial:Velocidades) {
		self = velocidadInicial
	}
}

class Auto {
	var velocidad = Velocidades(velocidadInicial: .Apagado)
	
	init() {
		Velocidades.init(velocidadInicial: .Apagado)
	}
	
	func cambioDeVelocidad() -> (actual:Int, velocidadeEnCadena:String) {
		if (velocidad.rawValue == 0) {
			velocidad = Velocidades(velocidadInicial: .VelocidadBaja)
			return (0, "Apagado")
		}
		else if (velocidad.rawValue == 20) {
			velocidad = Velocidades(velocidadInicial: .VelocidadMedia)
			return (20, "Velocidad baja")
		}
		else if (velocidad.rawValue == 50) {
			velocidad = Velocidades(velocidadInicial: .VelocidadAlta)
			return (50, "Velocidad media")
		}
		else {
			velocidad = Velocidades(velocidadInicial: .VelocidadMedia)
			return (120, "Velocidad alta")
		}
	}
}


// Teste
var auto = Auto()
for i in 0..<20 {
	print(auto.cambioDeVelocidad())
}